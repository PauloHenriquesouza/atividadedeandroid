package com.example.atividadedm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ed1;
    EditText ed2;
    EditText ed3;
    EditText ed4;
    EditText ed5;
    EditText ed6;
    Button bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ed1 = (EditText) findViewById(R.id.edt_consumo);
        ed2 = (EditText) findViewById(R.id.edt_couvert_artistico);
        ed3 = (EditText) findViewById(R.id.edt_dividir);
        ed4 = (EditText) findViewById(R.id.edt_servico);
        ed5 = (EditText) findViewById(R.id.edt_conta_total);
        ed6 = (EditText) findViewById(R.id.edt_valor_pessoa);
        bt = (Button) findViewById(R.id.bt_calcular);

        ((Button) bt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double ct;
                double ca;
                double dc;
                double tx;
                double rt;
                double rp;

                ct = Double.parseDouble(ed1.getText().toString());
                ca = Double.parseDouble(ed2.getText().toString());
                dc = Double.parseDouble(ed3.getText().toString());


                tx = ct/100*10;

                ed4.setText(""+tx);

                 rt = ct+ca+tx;
                rp = rt/dc;

                ed5.setText(""+rt);
                ed5.setText(""+rp);


            }
        });
    }
}


